Die Datei "START.bat" ist auszuführen. Bitte Berechtigung erlauben.
Python muss installiert sein.
Es öffnet sich ein Command Prompt.
Es ist zu beachten, dass die Dateien: "Graph_Dijk2_1.txt" und "Graph_Dijk2_2.txt" sich im selben Ordner befinden, wie die Datei "main.py".
Es wurde der Code-Editor Visual Studio Code verwendet.